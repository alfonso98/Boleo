/* ============================================================
   BOLEO ADMINISTRADORA — main.js
   ============================================================ */

import { BOLEO_API_ENDPOINT, BOLEO_API_TOKEN } from './constants.js';

(function () {
  'use strict';

  /* ── Theme Toggle ─────────────────────────────────────────── */
  const html       = document.documentElement;
  const themeBtn   = document.getElementById('theme-toggle');
  const themeIcon  = document.getElementById('theme-icon');

  function applyTheme(dark) {
    if (dark) {
      html.classList.add('dark-mode');
      themeIcon.className = 'fas fa-sun';
    } else {
      html.classList.remove('dark-mode');
      themeIcon.className = 'fas fa-moon';
    }
  }

  function initTheme() {
    const saved = localStorage.getItem('boleo-theme');
    if (saved) {
      applyTheme(saved === 'dark');
    } else {
      applyTheme(window.matchMedia('(prefers-color-scheme: dark)').matches);
    }
  }

  themeBtn && themeBtn.addEventListener('click', function () {
    const isDark = html.classList.contains('dark-mode');
    applyTheme(!isDark);
    localStorage.setItem('boleo-theme', isDark ? 'light' : 'dark');
  });

  initTheme();

  /* ── Mobile Nav ───────────────────────────────────────────── */
  const hamburger = document.getElementById('hamburger');
  const navLinks  = document.getElementById('nav-links');

  hamburger && hamburger.addEventListener('click', function () {
    const isOpen = navLinks.classList.toggle('open');
    hamburger.classList.toggle('open', isOpen);
    hamburger.setAttribute('aria-expanded', String(isOpen));
    document.body.style.overflow = isOpen ? 'hidden' : '';
  });

  navLinks && navLinks.querySelectorAll('.nav-link').forEach(function (link) {
    link.addEventListener('click', function () {
      navLinks.classList.remove('open');
      hamburger && hamburger.classList.remove('open');
      hamburger && hamburger.setAttribute('aria-expanded', 'false');
      document.body.style.overflow = '';
    });
  });

  /* ── Header scroll shadow ─────────────────────────────────── */
  const header = document.getElementById('site-header');
  window.addEventListener('scroll', function () {
    header && header.classList.toggle('scrolled', window.scrollY > 10);
  }, { passive: true });

  /* ── Active nav link on scroll (Intersection Observer) ────── */
  const sections  = document.querySelectorAll('main section[id]');
  const navItems  = document.querySelectorAll('.nav-link');

  const observerOptions = {
    rootMargin: '-40% 0px -55% 0px',
    threshold: 0,
  };

  const sectionObserver = new IntersectionObserver(function (entries) {
    entries.forEach(function (entry) {
      if (entry.isIntersecting) {
        const id = entry.target.getAttribute('id');
        navItems.forEach(function (item) {
          item.classList.toggle('active', item.getAttribute('href') === '#' + id);
        });
      }
    });
  }, observerOptions);

  sections.forEach(function (section) { sectionObserver.observe(section); });

  /* ── Multi-step Cotizador Form ────────────────────────────── */
  const form       = document.getElementById('cotizador-form');
  const stepEls    = document.querySelectorAll('.form-step');
  const indicators = document.querySelectorAll('.form-steps .step');
  const stepLines  = document.querySelectorAll('.step-line');

  function showStep(num) {
    stepEls.forEach(function (el) { el.classList.remove('active'); });
    const target = document.getElementById('step-' + num);
    if (target) target.classList.add('active');

    indicators.forEach(function (ind) {
      const n = parseInt(ind.dataset.step, 10);
      ind.classList.toggle('active', n === num);
      ind.classList.toggle('completed', n < num);
    });

    stepLines.forEach(function (line, i) {
      line.classList.toggle('completed', i < num - 1);
    });
  }

  function validateStep(stepNum) {
    const step = document.getElementById('step-' + stepNum);
    if (!step) return true;

    let valid = true;

    if (stepNum === 1) {
      const dept = step.querySelector('#departamentos');
      const presupuesto = step.querySelector('#presupuesto');
      const ubicacion = step.querySelector('#ubicacion');

      [dept, presupuesto].forEach(function (field) {
        if (!field.value) {
          field.classList.add('error');
          valid = false;
        } else {
          field.classList.remove('error');
        }
      });

      if (!ubicacion.value.trim()) {
        ubicacion.classList.add('error');
        valid = false;
      } else {
        ubicacion.classList.remove('error');
      }

    }

    if (stepNum === 2) {
      const adminRadios = step.querySelectorAll('input[name="administracion"]');
      const prosocRadios = step.querySelectorAll('input[name="prosoc"]');

      if (![...adminRadios].some(r => r.checked)) valid = false;
      if (![...prosocRadios].some(r => r.checked)) valid = false;
    }

    if (stepNum === 3) {
      const nombre   = step.querySelector('#nombre');
      const email    = step.querySelector('#email');
      const telefono = step.querySelector('#telefono');

      [nombre, email, telefono].forEach(function (field) {
        if (!field.value.trim()) {
          field.classList.add('error');
          valid = false;
        } else {
          field.classList.remove('error');
        }
      });

      if (email.value && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.value)) {
        email.classList.add('error');
        valid = false;
      }
    }

    return valid;
  }

  document.querySelectorAll('.btn-next').forEach(function (btn) {
    btn.addEventListener('click', function () {
      const current = parseInt(this.closest('.form-step').id.replace('step-', ''), 10);
      if (!validateStep(current)) {
        shakeForm();
        return;
      }
      showStep(parseInt(this.dataset.next, 10));
      scrollToForm();
    });
  });

  document.querySelectorAll('.btn-prev').forEach(function (btn) {
    btn.addEventListener('click', function () {
      showStep(parseInt(this.dataset.prev, 10));
      scrollToForm();
    });
  });

  const COTIZADOR_ENDPOINT = BOLEO_API_ENDPOINT;
  const COTIZADOR_TOKEN    = BOLEO_API_TOKEN;
  const submitBtn  = document.getElementById('cotizador-submit');
  const submitError = document.getElementById('form-submit-error');

  function pad2(n) { return String(n).padStart(2, '0'); }

  function nowForApi() {
    const d = new Date();
    return d.getFullYear() + '-' + pad2(d.getMonth() + 1) + '-' + pad2(d.getDate()) +
      ' ' + pad2(d.getHours()) + ':' + pad2(d.getMinutes());
  }

  function buildCotizadorPayload() {
    const data = new FormData(form);

    const extras = [];
    extras.push('Servicio de seguridad actual: ' + (data.get('seguridad') === 'si' ? 'Sí' : 'No'));
    extras.push('Servicio de limpieza actual: ' + (data.get('limpieza') === 'si' ? 'Sí' : 'No'));
    const servicios = data.getAll('servicios[]');
    if (servicios.length) extras.push('Servicios de interés: ' + servicios.join(', '));
    const mensaje = (data.get('mensaje') || '').trim();
    if (mensaje) extras.push(mensaje);

    return {
      nombre_cliente: data.get('nombre'),
      correo_cliente: data.get('email'),
      telefono_cliente: data.get('telefono'),
      ubicacion_inmueble: data.get('ubicacion'),
      presupuesto_mensual: data.get('presupuesto'),
      cuenta_con_administracion: data.get('administracion') === 'si',
      cuenta_con_certificacion_prosoc: data.get('prosoc') === 'si',
      cantidad_departamentos: data.get('departamentos'),
      comentario: extras.join(' | '),
      fecha_consulta: nowForApi(),
      source: 'Website Form',
    };
  }

  function setSubmitting(isSubmitting) {
    if (!submitBtn) return;
    submitBtn.disabled = isSubmitting;
    submitBtn.classList.toggle('is-loading', isSubmitting);
    const label = submitBtn.querySelector('.btn-label');
    if (label) label.textContent = isSubmitting ? 'Enviando…' : 'Solicitar cotización';
  }

  form && form.addEventListener('submit', function (e) {
    e.preventDefault();
    if (!validateStep(3)) { shakeForm(); return; }

    submitError && submitError.setAttribute('hidden', '');
    setSubmitting(true);

    console.info('Cotizador payload:', buildCotizadorPayload());

    fetch(COTIZADOR_ENDPOINT, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Authorization': 'Bearer ' + COTIZADOR_TOKEN,
      },
      body: JSON.stringify(buildCotizadorPayload()),
    })
      .then(function (res) {
        if (!res.ok) throw new Error('Request failed with status ' + res.status);
        return res.json().catch(function () { return null; });
      })
      .then(function () {
        stepEls.forEach(function (el) { el.classList.remove('active'); });
        const success = document.getElementById('step-success');
        if (success) success.classList.add('active');
        document.querySelector('.form-steps') && (document.querySelector('.form-steps').style.display = 'none');
        scrollToForm();
      })
      .catch(function (err) {
        console.error('Cotizador submit failed:', err);
        submitError && submitError.removeAttribute('hidden');
        shakeForm();
      })
      .finally(function () {
        setSubmitting(false);
      });

  });

  function scrollToForm() {
    const wrapper = document.querySelector('.cotizador-form-wrapper');
    if (wrapper) {
      const top = wrapper.getBoundingClientRect().top + window.scrollY - 100;
      window.scrollTo({ top, behavior: 'smooth' });
    }
  }

  function shakeForm() {
    const wrapper = document.querySelector('.cotizador-form-wrapper');
    if (!wrapper) return;
    wrapper.style.animation = 'none';
    wrapper.offsetHeight;
    wrapper.style.animation = 'shake 0.4s ease';
    setTimeout(function () { wrapper.style.animation = ''; }, 400);
  }

  const shakeKeyframes = `
    @keyframes shake {
      0%,100% { transform: translateX(0); }
      20%      { transform: translateX(-6px); }
      40%      { transform: translateX(6px); }
      60%      { transform: translateX(-4px); }
      80%      { transform: translateX(4px); }
    }
  `;
  const styleSheet = document.createElement('style');
  styleSheet.textContent = shakeKeyframes;
  document.head.appendChild(styleSheet);

  /* ── Nosotros image slideshow ─────────────────────────────── */
  const slideshowImgs = document.querySelectorAll('.nosotros-slideshow img');
  if (slideshowImgs.length > 1) {
    let current = 0;
    setInterval(function () {
      slideshowImgs[current].classList.remove('active');
      current = (current + 1) % slideshowImgs.length;
      slideshowImgs[current].classList.add('active');
    }, 15000);
  }

  /* ── Testimonial "read more" dialog ───────────────────────── */
  const TESTIMONIAL_TRUNCATE_LENGTH = 180;
  const testimonialDialog = document.getElementById('testimonial-dialog');

  if (testimonialDialog) {
    const dialogStars  = document.getElementById('testimonial-dialog-stars');
    const dialogText   = document.getElementById('testimonial-dialog-text');
    const dialogAvatar = document.getElementById('testimonial-dialog-avatar');
    const dialogName   = document.getElementById('testimonial-dialog-name');
    const dialogRole   = document.getElementById('testimonial-dialog-role');
    const dialogClose  = document.getElementById('testimonial-dialog-close');

    document.querySelectorAll('.testimonial-card').forEach(function (card) {
      const textEl = card.querySelector('.testimonial-text');
      if (!textEl) return;

      const fullText = textEl.textContent.trim();
      if (fullText.length <= TESTIMONIAL_TRUNCATE_LENGTH) return;

      textEl.classList.add('is-truncated');

      const readMoreBtn = document.createElement('button');
      readMoreBtn.type = 'button';
      readMoreBtn.className = 'testimonial-read-more';
      readMoreBtn.textContent = 'Leer más';
      textEl.insertAdjacentElement('afterend', readMoreBtn);

      readMoreBtn.addEventListener('click', function () {
        const starsCount = card.querySelectorAll('.testimonial-stars .fa-star').length;
        dialogStars.innerHTML = '<i class="fas fa-star" aria-hidden="true"></i>'.repeat(starsCount);
        dialogText.textContent = fullText;
        dialogAvatar.textContent = card.querySelector('.testimonial-avatar').textContent;
        dialogName.textContent = card.querySelector('.testimonial-info strong').textContent;
        dialogRole.textContent = card.querySelector('.testimonial-info span').textContent;
        testimonialDialog.showModal();
      });
    });

    dialogClose && dialogClose.addEventListener('click', function () {
      testimonialDialog.close();
    });

    testimonialDialog.addEventListener('click', function (e) {
      const rect = testimonialDialog.getBoundingClientRect();
      const inside = e.clientX >= rect.left && e.clientX <= rect.right &&
        e.clientY >= rect.top && e.clientY <= rect.bottom;
      if (!inside) testimonialDialog.close();
    });
  }

  /* ── Remove error state on input ──────────────────────────── */
  form && form.querySelectorAll('input, select, textarea').forEach(function (field) {
    field.addEventListener('input', function () { this.classList.remove('error'); });
    field.addEventListener('change', function () { this.classList.remove('error'); });
  });

})();
